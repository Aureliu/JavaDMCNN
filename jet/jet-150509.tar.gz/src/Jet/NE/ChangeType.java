// -*- tab-width: 4 -*-
/**
 *
 */
package Jet.NE;

enum ChangeType {
	NORMAL, FORCE
}
