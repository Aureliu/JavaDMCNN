// -*- tab-width: 4 -*-
package Jet.NE;

public class DictionaryFormatException extends Exception {
	public DictionaryFormatException(String msg) {
		super(msg);
	}
}
