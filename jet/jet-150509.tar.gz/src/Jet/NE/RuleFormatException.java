// -*- tab-width: 4 -*-
package Jet.NE;

public class RuleFormatException extends Exception {
	public RuleFormatException() {
		this(null);
	}

	public RuleFormatException(String msg) {
		super(msg);
	}
}
