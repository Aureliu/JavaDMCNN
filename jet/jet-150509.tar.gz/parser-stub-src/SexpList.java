package danbikel.lisp;

public class SexpList extends Sexp {

	public SexpList () { };

	public void add (Sexp x) { 
		throw new UnsupportedOperationException("dbparser not supported");
	};

	public int length() { 
		throw new UnsupportedOperationException("dbparser not supported");
	};

	public Sexp get (int i) { 
		throw new UnsupportedOperationException("dbparser not supported");
	};

}
