package danbikel.lisp;

public class Sexp { 

	public boolean isSymbol () {
		throw new UnsupportedOperationException("dbparser not supported");
	}

	public boolean isList () {
		throw new UnsupportedOperationException("dbparser not supported");
	}

}
