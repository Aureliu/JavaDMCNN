package danbikel.parser;

public class Settings {

	public static void load (String s) {
		throw new UnsupportedOperationException("dbparser not supported");
	}
}
