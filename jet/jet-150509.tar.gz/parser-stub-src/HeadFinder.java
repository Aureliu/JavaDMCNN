package danbikel.parser.english;

import danbikel.lisp.Sexp;
import java.io.IOException;

public class HeadFinder {

	public HeadFinder () throws IOException { };

	public int findHead (Sexp sx) {
		throw new UnsupportedOperationException("dbparser not supported");
	};

}
