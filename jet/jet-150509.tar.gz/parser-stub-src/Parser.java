package danbikel.parser;

import danbikel.lisp.SexpList;

public class Parser {

	public Parser (String grammarFile) {
		throw new UnsupportedOperationException("dbparser not supported");
	}

	public SexpList parse (SexpList sentence) {
		throw new UnsupportedOperationException("dbparser not supported");
	}

}
