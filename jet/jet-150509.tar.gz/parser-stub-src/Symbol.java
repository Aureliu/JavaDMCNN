package danbikel.lisp;

public class Symbol extends Sexp {

	public static Symbol get (String s) {
		throw new UnsupportedOperationException("dbparser not supported");
	}

}
